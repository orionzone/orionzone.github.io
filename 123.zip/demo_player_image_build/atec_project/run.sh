#!/bin/bash
DIR1="`dirname $BASH_SOURCE`"
MYDIR=`readlink -f "$DIR1"`
cd ${MYDIR}
#source timesharing_env/bin/activate
#export PYTHONHOME=${MYDIR}/timesharing_env
echo "start player code"
/home/admin/atec_project/timesharing-scheduler
